"""
VR-6000 Height Map Stitching - CON VERIFICACIÓN DE CALIDAD DE OVERLAP
========================================================================
"""

import numpy as np
from scipy import ndimage
from scipy.signal import fftconvolve
import matplotlib.pyplot as plt
from pathlib import Path
import logging
from typing import Tuple, List, Optional, Dict
from dataclasses import dataclass
from datetime import datetime
import re


logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)


@dataclass
class StitchConfig:
    pixel_size_mm: float = 0.007413
    expected_overlap_mm: float = 3.0
    max_delta_z_mm: float = 0.15
    min_snr: float = 3.0
    max_row_shift_px: int = 15
    smoothing_sigma: float = 1.0
    use_fallback: bool = True


@dataclass
class OverlapMetrics:
    """Métricas de calidad del overlap"""
    mae_um: float
    rmse_um: float
    std_um: float
    max_um: float
    n_points: int
    verdict: str  # "EXCELLENT", "GOOD", "ACCEPTABLE", "FAIL"
    
    
@dataclass
class StitchResult:
    heightmap: np.ndarray
    overlap_px: int
    overlap_mm: float
    row_shift: int
    delta_z_mm: float
    delta_z_std_mm: float
    correlation_snr: float
    valid_overlap_points: int
    used_fallback: bool = False
    original_file_width_px: int = 0
    overlap_metrics: Optional[OverlapMetrics] = None  # ✅ NUEVO


def validate_heightmap(H: np.ndarray, name: str) -> None:
    if H is None or H.size == 0:
        raise ValueError(f"{name}: Empty heightmap")
    if H.ndim != 2:
        raise ValueError(f"{name}: Must be 2D array")
    valid_fraction = np.sum(~np.isnan(H)) / H.size
    if valid_fraction < 0.1:
        raise ValueError(f"{name}: Too many NaN values")


def find_valid_range(H: np.ndarray) -> Tuple[int, int]:
    valid_mask = ~np.isnan(H)
    cols_with_data = np.sum(valid_mask, axis=0)
    valid_cols = np.where(cols_with_data > H.shape[0] * 0.1)[0]
    if len(valid_cols) == 0:
        return 0, H.shape[1]
    return int(valid_cols[0]), int(valid_cols[-1] + 1)


def normalize_data(data: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    valid_mask = ~np.isnan(data)
    if np.sum(valid_mask) < 10:
        return np.zeros_like(data), valid_mask
    mean_val = np.nanmean(data)
    std_val = np.nanstd(data)
    normalized = data.copy()
    if std_val > 1e-10:
        normalized = (data - mean_val) / std_val
    else:
        normalized = data - mean_val
    normalized[~valid_mask] = 0
    return normalized, valid_mask


def smooth_heightmap(H: np.ndarray, sigma: float) -> np.ndarray:
    return ndimage.gaussian_filter(H, sigma=sigma, mode='constant', cval=np.nan)


def load_vr6000_csv(filepath: str) -> Tuple[np.ndarray, float]:
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        pixel_size = None
        for i, line in enumerate(lines[:50]):
            if 'xy' in line.lower() and 'calibration' in line.lower():
                numbers = re.findall(r'(\d+\.?\d*(?:[eE][+-]?\d+)?)', line)
                if numbers:
                    value = float(numbers[0])
                    if value > 0.1:
                        pixel_size = value / 1000.0
                        print(f"✓ XY Calibration: {value} um = {pixel_size} mm")
                    else:
                        pixel_size = value
                        print(f"✓ XY Calibration: {value} mm")
                    break
        
        if pixel_size is None:
            print(f"\n⚠️  No XY Calibration en {Path(filepath).name}")
            value_input = input(f"XY Calibration: ").strip()
            value = float(re.findall(r'(\d+\.?\d*)', value_input)[0])
            if value > 0.1:
                pixel_size = value / 1000.0
            else:
                pixel_size = value
        
        data_start = 0
        for i, line in enumerate(lines):
            line_stripped = line.strip()
            if line_stripped.startswith('Height,'):
                parts = line_stripped.split(',')
                if all(p == '' for p in parts[1:]):
                    data_start = i + 1
                    break
        if data_start == 0:
            data_start = 22
        
        data = []
        for line in lines[data_start:]:
            if not line.strip():
                continue
            vals = [x.strip().strip('"') for x in line.strip().split(',')]
            row = []
            for v in vals:
                if v == '' or v == '""':
                    row.append(np.nan)
                else:
                    try:
                        row.append(float(v))
                    except:
                        row.append(np.nan)
            data.append(row)
        
        H = np.array(data, dtype=float)
        H[H < -10] = np.nan
        H[H > 10] = np.nan
        
        logger.info(f"Loaded {Path(filepath).name}: {H.shape}")
        return H, pixel_size
        
    except Exception as e:
        logger.error(f"Error: {e}")
        raise


def extract_search_bands(H_left, H_right, expected_overlap_px, config):
    left_start, left_end = find_valid_range(H_left)
    right_start, right_end = find_valid_range(H_right)
    search_margin = int(expected_overlap_px * 0.5)
    band_width = expected_overlap_px + search_margin
    band_left_start = max(left_start, left_end - band_width)
    band_left = H_left[:, band_left_start:left_end].copy()
    band_right_end = min(right_end, right_start + band_width)
    band_right = H_right[:, right_start:band_right_end].copy()
    band_left = smooth_heightmap(band_left, config.smoothing_sigma)
    band_right = smooth_heightmap(band_right, config.smoothing_sigma)
    band_left_norm, _ = normalize_data(band_left)
    band_right_norm, _ = normalize_data(band_right)
    return band_left_norm, band_right_norm


def find_overlap_via_correlation(band_left, band_right, H_left, config):
    try:
        correlation = fftconvolve(band_left, band_right[::-1, ::-1], mode='full')
        max_idx = np.unravel_index(np.argmax(correlation), correlation.shape)
        max_corr_value = correlation[max_idx]
        corr_row, corr_col = max_idx
        corr_std = np.nanstd(correlation)
        snr = max_corr_value / corr_std if corr_std > 0 else 0
        overlap_cols = corr_col - (band_right.shape[1] - 1)
        left_start, left_end = find_valid_range(H_left)
        band_width = band_left.shape[1]
        band_left_start = max(left_start, left_end - band_width)
        overlap_absolute = left_end - (band_left_start + overlap_cols)
        
        if overlap_absolute <= 0 or overlap_absolute > min(H_left.shape[1], band_right.shape[1]):
            if config.use_fallback:
                return None, 0, snr
            raise ValueError(f"Invalid overlap: {overlap_absolute}")
        
        if snr < config.min_snr:
            if config.use_fallback:
                return None, 0, snr
            raise ValueError(f"Low SNR: {snr:.2f}")
        
        row_shift = corr_row - (band_left.shape[0] - 1)
        if abs(row_shift) > config.max_row_shift_px:
            row_shift = np.clip(row_shift, -config.max_row_shift_px, config.max_row_shift_px)
        
        return overlap_absolute, row_shift, snr
    except Exception as e:
        if config.use_fallback:
            return None, 0, 0.0
        raise


def calculate_height_offset(H_left, H_right, overlap_px, row_shift, config):
    min_rows = min(H_left.shape[0], H_right.shape[0])
    overlap_start_left = H_left.shape[1] - overlap_px
    overlap_end_left = H_left.shape[1]
    overlap_start_right = 0
    overlap_end_right = overlap_px
    
    if row_shift > 0:
        left_crop = H_left[row_shift:row_shift+min_rows, overlap_start_left:overlap_end_left]
        right_crop = H_right[0:min_rows, overlap_start_right:overlap_end_right]
    else:
        left_crop = H_left[0:min_rows, overlap_start_left:overlap_end_left]
        right_crop = H_right[-row_shift:-row_shift+min_rows, overlap_start_right:overlap_end_right]
    
    min_overlap_rows = min(left_crop.shape[0], right_crop.shape[0])
    min_overlap_cols = min(left_crop.shape[1], right_crop.shape[1])
    region_left = left_crop[:min_overlap_rows, :min_overlap_cols]
    region_right = right_crop[:min_overlap_rows, :min_overlap_cols]
    valid_overlap = ~np.isnan(region_left) & ~np.isnan(region_right)
    
    if np.sum(valid_overlap) < 10:
        return 0.0, 0.0
    
    diff = region_right[valid_overlap] - region_left[valid_overlap]
    delta_z = np.nanmedian(diff)
    delta_z_std = np.nanstd(diff)
    return delta_z, delta_z_std


def assemble_stitched_heightmap(H_left, H_right, overlap_px, row_shift, delta_z):
    H_right_corrected = H_right - delta_z
    
    if row_shift > 0:
        usable_rows_left = H_left.shape[0] - row_shift
        usable_rows_right = H_right.shape[0]
    else:
        usable_rows_left = H_left.shape[0]
        usable_rows_right = H_right.shape[0] + row_shift
    
    final_rows = min(usable_rows_left, usable_rows_right)
    final_cols = H_left.shape[1] + H_right.shape[1] - overlap_px
    H_stitched = np.full((final_rows, final_cols), np.nan)
    
    if row_shift > 0:
        H_stitched[:, :H_left.shape[1]] = H_left[row_shift:row_shift+final_rows, :]
    else:
        H_stitched[:, :H_left.shape[1]] = H_left[0:final_rows, :]
    
    start_col = H_left.shape[1] - overlap_px
    
    if row_shift > 0:
        new_data = H_right_corrected[0:final_rows, :]
    else:
        offset = -row_shift
        new_data = H_right_corrected[offset:offset+final_rows, :]
    
    old_data = H_stitched[:, start_col:start_col+H_right.shape[1]]
    H_stitched[:, start_col:start_col+H_right.shape[1]] = np.where(
        ~np.isnan(new_data),
        new_data,
        old_data
    )
    
    overlap_region = slice(start_col, H_left.shape[1])
    
    if row_shift > 0:
        left_overlap = H_left[row_shift:row_shift+final_rows, -overlap_px:]
        right_overlap = H_right_corrected[0:final_rows, :overlap_px]
    else:
        left_overlap = H_left[0:final_rows, -overlap_px:]
        offset = -row_shift
        right_overlap = H_right_corrected[offset:offset+final_rows, :overlap_px]
    
    if left_overlap.shape == right_overlap.shape:
        stacked = np.dstack((left_overlap, right_overlap))
        with np.errstate(invalid='ignore'):
            overlap_avg = np.nanmean(stacked, axis=2)
            old_overlap = H_stitched[:, overlap_region]
            H_stitched[:, overlap_region] = np.where(
                ~np.isnan(overlap_avg),
                overlap_avg,
                old_overlap
            )
    
    return H_stitched


# ============================================================================
# ✅ NUEVA FUNCIÓN: VERIFICACIÓN DE CALIDAD DE OVERLAP
# ============================================================================

def verify_overlap_quality(H_left, H_right, overlap_px, row_shift, delta_z, 
                          pixel_size_mm, pair_name="", output_dir=None) -> OverlapMetrics:
    """
    Calcula métricas de calidad del overlap entre dos heightmaps.
    
    Returns:
        OverlapMetrics con MAE, RMSE, STD, MAX en micrones
    """
    
    # Extraer regiones de overlap alineadas
    min_rows = min(H_left.shape[0], H_right.shape[0])
    overlap_start_left = H_left.shape[1] - overlap_px
    overlap_end_left = H_left.shape[1]
    overlap_start_right = 0
    overlap_end_right = overlap_px
    
    # Aplicar row_shift
    if row_shift > 0:
        left_overlap = H_left[row_shift:row_shift+min_rows, overlap_start_left:overlap_end_left]
        right_overlap = H_right[0:min_rows, overlap_start_right:overlap_end_right]
    else:
        left_overlap = H_left[0:min_rows, overlap_start_left:overlap_end_left]
        right_overlap = H_right[-row_shift:-row_shift+min_rows, overlap_start_right:overlap_end_right]
    
    # Recortar a mismas dimensiones
    min_overlap_rows = min(left_overlap.shape[0], right_overlap.shape[0])
    min_overlap_cols = min(left_overlap.shape[1], right_overlap.shape[1])
    left_overlap = left_overlap[:min_overlap_rows, :min_overlap_cols]
    right_overlap = right_overlap[:min_overlap_rows, :min_overlap_cols]
    
    # Aplicar corrección de delta_z
    right_overlap_corrected = right_overlap - delta_z
    
    # Calcular diferencias
    valid_mask = ~np.isnan(left_overlap) & ~np.isnan(right_overlap_corrected)
    
    if np.sum(valid_mask) < 100:
        logger.warning(f"{pair_name}: Insufficient valid points for verification")
        return OverlapMetrics(
            mae_um=np.nan, rmse_um=np.nan, std_um=np.nan, 
            max_um=np.nan, n_points=0, verdict="INSUFFICIENT_DATA"
        )
    
    diff_mm = left_overlap[valid_mask] - right_overlap_corrected[valid_mask]
    diff_um = diff_mm * 1000  # Convertir a micrones
    
    # Filtrar outliers extremos (> 3σ)
    mean_diff = np.mean(diff_um)
    std_diff = np.std(diff_um)
    outlier_mask = np.abs(diff_um - mean_diff) < 3 * std_diff
    diff_um_filtered = diff_um[outlier_mask]
    n_outliers = len(diff_um) - len(diff_um_filtered)
    
    # Calcular métricas
    mae = np.mean(np.abs(diff_um_filtered))
    rmse = np.sqrt(np.mean(diff_um_filtered**2))
    std = np.std(diff_um_filtered)
    max_err = np.max(np.abs(diff_um_filtered))
    n_points = len(diff_um_filtered)
    
    # Determinar veredicto
    if mae < 5:
        verdict = "EXCELLENT"
    elif mae < 10:
        verdict = "GOOD"
    elif mae < 15:
        verdict = "ACCEPTABLE"
    else:
        verdict = "FAIL"
    
    metrics = OverlapMetrics(
        mae_um=mae, rmse_um=rmse, std_um=std, 
        max_um=max_err, n_points=n_points, verdict=verdict
    )
    
    # Log resultados
    logger.info(f"\n{'='*60}")
    logger.info(f"OVERLAP VERIFICATION: {pair_name}")
    logger.info(f"{'='*60}")
    logger.info(f"Overlap size: {overlap_px} px ({overlap_px*pixel_size_mm:.2f} mm)")
    logger.info(f"Valid points: {n_points:,}")
    if n_outliers > 0:
        logger.info(f"Outliers removed: {n_outliers} ({100*n_outliers/len(diff_um):.1f}%)")
    logger.info(f"\nERROR METRICS:")
    logger.info(f"  MAE:  {mae:.2f} µm")
    logger.info(f"  RMSE: {rmse:.2f} µm")
    logger.info(f"  STD:  {std:.2f} µm")
    logger.info(f"  MAX:  {max_err:.2f} µm")
    logger.info(f"\nVERDICT: {verdict}")
    logger.info(f"{'='*60}\n")
    
    # Guardar outputs si se especifica directorio
    if output_dir is not None:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # CSV con errores
        safe_pair_name = pair_name.replace("->", "_to_")  # Fix Windows invalid chars
        save_overlap_error_csv(
            left_overlap, right_overlap_corrected, diff_mm,
            valid_mask, pixel_size_mm, output_path / f"overlap_{safe_pair_name}_errors.csv"
        )
        
        # Plot diagnóstico
        plot_overlap_diagnostics(
            left_overlap, right_overlap_corrected, diff_um_filtered,
            pixel_size_mm, pair_name, metrics,
            output_path / f"overlap_{safe_pair_name}_diagnostics.png"
        )
    
    return metrics


def save_overlap_error_csv(left_overlap, right_overlap, diff_mm, valid_mask, 
                           pixel_size_mm, filepath):
    """Guarda CSV con coordenadas y errores del overlap"""
    rows, cols = left_overlap.shape
    
    # Reconstruir array 2D de diferencias
    diff_2d = np.full((rows, cols), np.nan)
    diff_2d[valid_mask] = diff_mm
    
    with open(filepath, 'w') as f:
        f.write("X_mm,Y_mm,Z_left_mm,Z_right_mm,ERROR_um\n")
        for i in range(rows):
            for j in range(cols):
                if valid_mask[i, j]:
                    x_mm = j * pixel_size_mm
                    y_mm = i * pixel_size_mm
                    z_left = left_overlap[i, j]
                    z_right = right_overlap[i, j]
                    error_um = diff_2d[i, j] * 1000
                    f.write(f"{x_mm:.6f},{y_mm:.6f},{z_left:.6f},{z_right:.6f},{error_um:.3f}\n")
    
    logger.info(f"Saved error CSV: {Path(filepath).name}")


def plot_overlap_diagnostics(left_overlap, right_overlap_corrected, diff_um, 
                             pixel_size_mm, pair_name, metrics, filepath):
    """Genera plot de diagnóstico con 4 subplots"""
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # 1. Heatmap de error
    rows, cols = left_overlap.shape
    diff_2d = np.full((rows, cols), np.nan)
    valid_mask = ~np.isnan(left_overlap) & ~np.isnan(right_overlap_corrected)
    diff_2d[valid_mask] = (left_overlap[valid_mask] - right_overlap_corrected[valid_mask]) * 1000  # µm
    
    # Calcular límites dinámicos basados en percentiles
    valid_diffs = diff_2d[~np.isnan(diff_2d)]
    if len(valid_diffs) > 0:
        vmin = np.percentile(valid_diffs, 1)
        vmax = np.percentile(valid_diffs, 99)
        # Asegurar simetría alrededor de 0
        vabs = max(abs(vmin), abs(vmax))
        vmin, vmax = -vabs, vabs
    else:
        vmin, vmax = -20, 20
    
    extent = [0, cols*pixel_size_mm, 0, rows*pixel_size_mm]
    im = axes[0, 0].imshow(diff_2d, origin='lower', extent=extent, 
                           cmap='RdBu_r', vmin=vmin, vmax=vmax)
    axes[0, 0].set_title(f'Error Spatial Map - {pair_name}', fontweight='bold')
    axes[0, 0].set_xlabel('X (mm)')
    axes[0, 0].set_ylabel('Y (mm)')
    fig.colorbar(im, ax=axes[0, 0], label='Error (µm)')
    
    # 2. Histograma
    axes[0, 1].hist(diff_um, bins=50, edgecolor='black', alpha=0.7)
    axes[0, 1].axvline(0, color='red', linestyle='--', linewidth=2, label='Zero error')
    axes[0, 1].axvline(np.mean(diff_um), color='green', linestyle='-', 
                      linewidth=2, label=f'Mean: {np.mean(diff_um):.2f} µm')
    axes[0, 1].set_title('Error Distribution', fontweight='bold')
    axes[0, 1].set_xlabel('Error (µm)')
    axes[0, 1].set_ylabel('Frequency')
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3)
    
    # 3. Perfiles comparados (5 filas)
    x_mm = np.arange(cols) * pixel_size_mm
    rows_to_plot = [int(0.2*rows), int(0.4*rows), int(0.5*rows), 
                    int(0.6*rows), int(0.8*rows)]
    
    for row_idx in rows_to_plot:
        if row_idx < rows:
            axes[1, 0].plot(x_mm, left_overlap[row_idx, :]*1000, 
                          linewidth=1.5, alpha=0.7, label=f'Left {100*row_idx/rows:.0f}%')
            axes[1, 0].plot(x_mm, right_overlap_corrected[row_idx, :]*1000, 
                          linestyle='--', linewidth=1.5, alpha=0.7, 
                          label=f'Right {100*row_idx/rows:.0f}%')
    
    axes[1, 0].set_title('Profile Comparison', fontweight='bold')
    axes[1, 0].set_xlabel('X (mm)')
    axes[1, 0].set_ylabel('Height (µm)')
    axes[1, 0].legend(fontsize='small', ncol=2)
    axes[1, 0].grid(True, alpha=0.3)
    
    # 4. Métricas summary
    axes[1, 1].axis('off')
    
    # Color según veredicto
    color_map = {
        "EXCELLENT": "#00CC00",
        "GOOD": "#66CC00",
        "ACCEPTABLE": "#FFAA00",
        "FAIL": "#FF0000"
    }
    verdict_color = color_map.get(metrics.verdict, "#888888")
    
    summary_text = f"""
OVERLAP QUALITY METRICS

Pair: {pair_name}
Valid Points: {metrics.n_points:,}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ERROR STATISTICS (µm)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MAE:    {metrics.mae_um:.2f} µm
RMSE:   {metrics.rmse_um:.2f} µm
STD:    {metrics.std_um:.2f} µm
MAX:    {metrics.max_um:.2f} µm

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VERDICT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{metrics.verdict}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
QUALITY THRESHOLDS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

EXCELLENT:   MAE < 5 µm
GOOD:        MAE < 10 µm
ACCEPTABLE:  MAE < 15 µm
FAIL:        MAE ≥ 15 µm
    """
    
    axes[1, 1].text(0.05, 0.95, summary_text, 
                   transform=axes[1, 1].transAxes,
                   fontsize=11, verticalalignment='top',
                   fontfamily='monospace',
                   bbox=dict(boxstyle='round', facecolor='white', 
                            edgecolor=verdict_color, linewidth=3))
    
    plt.suptitle(f'OVERLAP VERIFICATION REPORT - {pair_name}', 
                fontsize=14, fontweight='bold', y=0.98)
    plt.tight_layout()
    plt.savefig(filepath, dpi=150, bbox_inches='tight')
    plt.close(fig)
    
    logger.info(f"Saved diagnostic plot: {Path(filepath).name}")


# ============================================================================
# ✅ MODIFICACIÓN: stitch_two_heightmaps ahora incluye verificación
# ============================================================================

def stitch_two_heightmaps(H_left, H_right, config, override_overlap_mm=None, 
                         original_right_width=None, pair_name="", verify_quality=True,
                         verification_output_dir=None):
    validate_heightmap(H_left, "H_left")
    validate_heightmap(H_right, "H_right")
    
    overlap_mm = override_overlap_mm if override_overlap_mm is not None else config.expected_overlap_mm
    expected_overlap_px = int(overlap_mm / config.pixel_size_mm)
    
    band_left, band_right = extract_search_bands(H_left, H_right, expected_overlap_px, config)
    overlap_px, row_shift, snr = find_overlap_via_correlation(band_left, band_right, H_left, config)
    
    used_fallback = False
    if overlap_px is None:
        overlap_px = expected_overlap_px
        row_shift = 0
        snr = 0.0
        used_fallback = True
    
    delta_z, delta_z_std = calculate_height_offset(H_left, H_right, overlap_px, row_shift, config)
    
    # ✅ VERIFICACIÓN DE CALIDAD (antes de ensamblar)
    overlap_metrics = None
    if verify_quality and not used_fallback:
        try:
            overlap_metrics = verify_overlap_quality(
                H_left, H_right, overlap_px, row_shift, delta_z,
                config.pixel_size_mm, pair_name, verification_output_dir
            )
        except Exception as e:
            logger.warning(f"Could not verify overlap quality: {e}")
    
    # Ensamblar heightmap
    H_stitched = assemble_stitched_heightmap(H_left, H_right, overlap_px, row_shift, delta_z)
    valid_overlap_points = int(np.sum(~np.isnan(H_stitched[:, H_left.shape[1]-overlap_px:H_left.shape[1]])))
    
    logger.info(f"Complete: {H_stitched.shape}, overlap: {overlap_px*config.pixel_size_mm:.2f}mm")
    
    return StitchResult(
        heightmap=H_stitched, overlap_px=overlap_px, overlap_mm=overlap_px*config.pixel_size_mm,
        row_shift=row_shift, delta_z_mm=delta_z, delta_z_std_mm=delta_z_std,
        correlation_snr=snr, valid_overlap_points=valid_overlap_points,
        used_fallback=used_fallback,
        original_file_width_px=original_right_width if original_right_width else H_right.shape[1],
        overlap_metrics=overlap_metrics  # ✅ NUEVO
    )


def configure_overlaps(num_files, default_overlap):
    print("\n" + "="*70)
    print("OVERLAP CONFIGURATION")
    print("="*70)
    print(f"Files: {num_files} ({num_files-1} operations)")
    print(f"Default: {default_overlap:.2f}mm")
    print("\n1. Same for all\n2. Different for each\n3. Auto (use default)")
    
    choice = input("\nChoice [1/2/3]: ").strip()
    
    if choice == "1":
        overlap = input(f"Overlap (mm) [{default_overlap:.2f}]: ").strip()
        overlap = float(overlap) if overlap else default_overlap
        return {i: overlap for i in range(num_files - 1)}
    elif choice == "2":
        overlaps = {}
        for i in range(num_files - 1):
            overlap = input(f"File {i+1}->{i+2} (mm) [{default_overlap:.2f}]: ").strip()
            overlaps[i] = float(overlap) if overlap else default_overlap
        return overlaps
    else:
        return {i: default_overlap for i in range(num_files - 1)}


def plot_heightmap_with_overlaps(H_final, all_results, pixel_size_mm, first_file_width_px, output_prefix):
    """✅ HEIGHTMAP CON OVERLAPS MARCADOS"""
    from matplotlib.colors import LinearSegmentedColormap
    
    vmin, vmax = -0.063, 0.065
    colors = ['#00008B', '#0000FF', '#00FFFF', '#FFFF00', '#FFA500', '#FF0000']
    positions = [0.0, 0.20, 0.38, 0.56, 0.73, 1.0]
    cmap = LinearSegmentedColormap.from_list('vr6200', list(zip(positions, colors)), N=256)
    
    fig, ax = plt.subplots(figsize=(20, 6))
    width = H_final.shape[1] * pixel_size_mm
    height = H_final.shape[0] * pixel_size_mm
    extent = [0, width, 0, height]
    
    im = ax.imshow(H_final, cmap=cmap, aspect='auto', extent=extent, vmin=vmin, vmax=vmax, origin='lower')
    
    # ✅ MARCAR OVERLAPS
    current_pos = first_file_width_px
    
    for i, result in enumerate(all_results):
        overlap_start_px = current_pos - result.overlap_px
        overlap_end_px = current_pos
        
        overlap_start_mm = overlap_start_px * pixel_size_mm
        overlap_end_mm = overlap_end_px * pixel_size_mm
        
        ax.axvline(overlap_start_mm, color='white', linewidth=2, linestyle='--', alpha=0.8)
        ax.axvline(overlap_end_mm, color='black', linewidth=2, linestyle='--', alpha=0.8)
        ax.axvspan(overlap_start_mm, overlap_end_mm, alpha=0.15, color='yellow')
        
        mid_overlap = (overlap_start_mm + overlap_end_mm) / 2
        
        # ✅ AÑADIR VEREDICTO DE CALIDAD
        quality_label = ""
        if result.overlap_metrics:
            quality_label = f"\n{result.overlap_metrics.verdict}"
        
        ax.text(mid_overlap, height * 0.95, f'Overlap {i+1}\n{result.overlap_mm:.1f}mm{quality_label}', 
                ha='center', va='top', fontsize=9,
                fontweight='bold', bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.7))
        
        current_pos += (result.original_file_width_px - result.overlap_px)
    
    ax.set_xlabel('Width (mm)', fontsize=12)
    ax.set_ylabel('Height (mm)', fontsize=12)
    ax.set_title(f'FINAL STITCHED HEIGHTMAP (WITH OVERLAPS)\n{width:.1f}x{height:.1f}mm | {len(all_results)} overlaps',
                fontsize=14, fontweight='bold')
    plt.colorbar(im, ax=ax, label='Height (mm)')
    plt.tight_layout()
    
    fname = f"{output_prefix}_WITH_overlaps.png"
    fig.savefig(fname, dpi=150, bbox_inches='tight')
    plt.close(fig)
    logger.info(f"Saved: {fname}")


def plot_heightmap_clean(H_final, pixel_size_mm, output_prefix):
    """✅ HEIGHTMAP LIMPIO"""
    from matplotlib.colors import LinearSegmentedColormap
    
    vmin, vmax = -0.063, 0.065
    colors = ['#00008B', '#0000FF', '#00FFFF', '#FFFF00', '#FFA500', '#FF0000']
    positions = [0.0, 0.20, 0.38, 0.56, 0.73, 1.0]
    cmap = LinearSegmentedColormap.from_list('vr6200', list(zip(positions, colors)), N=256)
    
    fig, ax = plt.subplots(figsize=(20, 6))
    width = H_final.shape[1] * pixel_size_mm
    height = H_final.shape[0] * pixel_size_mm
    extent = [0, width, 0, height]
    
    im = ax.imshow(H_final, cmap=cmap, aspect='auto', extent=extent, vmin=vmin, vmax=vmax, origin='lower')
    
    ax.set_xlabel('Width (mm)', fontsize=12)
    ax.set_ylabel('Height (mm)', fontsize=12)
    ax.set_title(f'FINAL STITCHED HEIGHTMAP (CLEAN)\n{width:.1f}x{height:.1f}mm',
                fontsize=14, fontweight='bold')
    plt.colorbar(im, ax=ax, label='Height (mm)')
    plt.tight_layout()
    
    fname = f"{output_prefix}_CLEAN.png"
    fig.savefig(fname, dpi=150, bbox_inches='tight')
    plt.close(fig)
    logger.info(f"Saved: {fname}")


def plot_profiles_with_overlaps(H_final, all_results, pixel_size_mm, first_file_width_px, output_prefix):
    """✅ 5 PERFILES CON OVERLAPS MARCADOS (EN MM)"""
    logger.info("Generating 5 continuity profiles...")
    
    fig, axes = plt.subplots(5, 1, figsize=(18, 14))
    rows_to_check = [H_final.shape[0]//5, 2*H_final.shape[0]//5, H_final.shape[0]//2, 
                     3*H_final.shape[0]//5, 4*H_final.shape[0]//5]
    
    for i, row in enumerate(rows_to_check):
        ax = axes[i]
        profile = H_final[row, :]
        valid = ~np.isnan(profile)
        
        # ✅ CONVERTIR A MM
        cols_mm = np.arange(len(profile)) * pixel_size_mm
        
        ax.plot(cols_mm[valid], profile[valid]*1000, 'b-', linewidth=1.5, alpha=0.8)
        
        # ✅ MARCAR OVERLAPS
        current_pos = first_file_width_px
        
        for j, result in enumerate(all_results):
            overlap_start_px = current_pos - result.overlap_px
            overlap_end_px = current_pos
            
            overlap_start_mm = overlap_start_px * pixel_size_mm
            overlap_end_mm = overlap_end_px * pixel_size_mm
            
            ax.axvline(overlap_start_mm, color='red', linestyle='--', linewidth=1.5, alpha=0.7)
            ax.axvline(overlap_end_mm, color='cyan', linestyle='--', linewidth=1.5, alpha=0.7)
            ax.axvspan(overlap_start_mm, overlap_end_mm, alpha=0.15, color='yellow')
            
            current_pos += (result.original_file_width_px - result.overlap_px)
        
        ax.set_ylabel('Height (μm)', fontsize=10)
        ax.set_title(f'Profile at row {row} ({100*row/H_final.shape[0]:.0f}%)', fontsize=11)
        ax.grid(True, alpha=0.3)
    
    axes[-1].set_xlabel('Position (mm)', fontsize=11)
    plt.suptitle('PROFILE CONTINUITY - All Overlaps', fontsize=14, fontweight='bold')
    plt.tight_layout()
    
    fname = f"{output_prefix}_profiles.png"
    fig.savefig(fname, dpi=150, bbox_inches='tight')
    plt.close(fig)
    logger.info(f"Saved: {fname}")


def save_csv_with_header(filepath, heightmap, pixel_size_mm):
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write('"Stitched Heightmap - Shipyard 4.0 MVP2"\n')
        f.write(f'"Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}"\n')
        f.write(f'"XY Calibration: {pixel_size_mm*1000:.3f} um"\n')
        f.write(f'"Dimensions: {heightmap.shape[1]} x {heightmap.shape[0]} pixels"\n')
        f.write(f'"Physical Size: {heightmap.shape[1]*pixel_size_mm:.2f} x {heightmap.shape[0]*pixel_size_mm:.2f} mm"\n')
        f.write(f'"Height Range: [{np.nanmin(heightmap):.6f}, {np.nanmax(heightmap):.6f}] mm"\n')
        f.write('""\n"Height"\n')
        np.savetxt(f, heightmap, delimiter=',', fmt='%.6f')
    logger.info(f"CSV saved: {Path(filepath).name}")


# ============================================================================
# ✅ NUEVA FUNCIÓN: GENERAR REPORTE FINAL DE CALIDAD
# ============================================================================

def generate_quality_report(all_results, output_file):
    """Genera reporte de texto con resumen de calidad de todos los overlaps"""
    
    n_total = len(all_results)
    n_excellent = sum(1 for r in all_results if r.overlap_metrics and r.overlap_metrics.verdict == "EXCELLENT")
    n_good = sum(1 for r in all_results if r.overlap_metrics and r.overlap_metrics.verdict == "GOOD")
    n_acceptable = sum(1 for r in all_results if r.overlap_metrics and r.overlap_metrics.verdict == "ACCEPTABLE")
    n_fail = sum(1 for r in all_results if r.overlap_metrics and r.overlap_metrics.verdict == "FAIL")
    n_pass = n_excellent + n_good + n_acceptable
    
    with open(output_file, 'w') as f:
        f.write("=" * 80 + "\n")
        f.write("STITCHING QUALITY VERIFICATION REPORT\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total pairs analyzed: {n_total}\n\n")
        
        f.write("-" * 80 + "\n")
        f.write("OVERALL SUMMARY\n")
        f.write("-" * 80 + "\n")
        f.write(f"PASS:  {n_pass}/{n_total} ({100*n_pass/n_total:.1f}%)\n")
        f.write(f"FAIL:  {n_fail}/{n_total} ({100*n_fail/n_total:.1f}%)\n\n")
        
        f.write(f"  EXCELLENT:  {n_excellent}\n")
        f.write(f"  GOOD:       {n_good}\n")
        f.write(f"  ACCEPTABLE: {n_acceptable}\n")
        f.write(f"  FAIL:       {n_fail}\n\n")
        
        f.write("-" * 80 + "\n")
        f.write("DETAILED RESULTS\n")
        f.write("-" * 80 + "\n\n")
        
        for i, result in enumerate(all_results):
            pair_name = f"{i+1}->{i+2}"
            f.write(f"Pair {pair_name}:\n")
            f.write(f"  Overlap: {result.overlap_mm:.2f} mm ({result.overlap_px} px)\n")
            f.write(f"  Delta Z: {result.delta_z_mm*1000:.2f} µm\n")
            f.write(f"  SNR:     {result.correlation_snr:.2f}\n")
            
            if result.overlap_metrics:
                m = result.overlap_metrics
                f.write(f"  MAE:     {m.mae_um:.2f} µm\n")
                f.write(f"  RMSE:    {m.rmse_um:.2f} µm\n")
                f.write(f"  STD:     {m.std_um:.2f} µm\n")
                f.write(f"  MAX:     {m.max_um:.2f} µm\n")
                f.write(f"  Points:  {m.n_points:,}\n")
                f.write(f"  VERDICT: {m.verdict}\n")
            else:
                f.write(f"  VERDICT: NO_VERIFICATION (fallback mode)\n")
            
            f.write("\n")
        
        f.write("-" * 80 + "\n")
        f.write("RECOMMENDATION\n")
        f.write("-" * 80 + "\n")
        
        if n_fail == 0:
            if n_excellent + n_good >= n_total * 0.8:
                recommendation = "EXCELLENT quality. Proceed with final stitching."
            else:
                recommendation = "ACCEPTABLE quality. Stitching is valid for most applications."
        else:
            recommendation = f"WARNING: {n_fail} pair(s) FAILED. Review failed overlaps before proceeding."
        
        f.write(f"{recommendation}\n\n")
        
        f.write("=" * 80 + "\n")
    
    logger.info(f"Quality report saved: {Path(output_file).name}")


def stitch_multiple_files(csv_files, output_dir=".", output_prefix="stitched", config=None, 
                         interactive=True, verify_quality=True):
    if config is None:
        config = StitchConfig()
    if len(csv_files) < 2:
        raise ValueError("Need at least 2 files")
    
    if interactive:
        overlaps = configure_overlaps(len(csv_files), config.expected_overlap_mm)
    else:
        overlaps = {i: config.expected_overlap_mm for i in range(len(csv_files) - 1)}
    
    logger.info("="*70)
    logger.info(f"STITCHING {len(csv_files)} FILES")
    logger.info("="*70)
    
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # ✅ Crear directorio para verificación
    verification_dir = output_path / "verification" if verify_quality else None
    if verification_dir:
        verification_dir.mkdir(parents=True, exist_ok=True)
    
    H_result, pixel_size_mm = load_vr6000_csv(csv_files[0])
    config.pixel_size_mm = pixel_size_mm
    first_file_width_px = H_result.shape[1]
    
    all_results = []
    
    for i, csv_file in enumerate(csv_files[1:]):
        logger.info(f"\n[{i+2}/{len(csv_files)}] Stitching {Path(csv_file).name}...")
        H_next, _ = load_vr6000_csv(csv_file)
        original_next_width = H_next.shape[1]
        
        result = stitch_two_heightmaps(
            H_result, H_next, config, 
            override_overlap_mm=overlaps[i],
            original_right_width=original_next_width,
            pair_name=f"{i+1}->{i+2}",
            verify_quality=verify_quality,
            verification_output_dir=str(verification_dir) if verification_dir else None
        )
        H_result = result.heightmap
        all_results.append(result)
    
    output_csv = output_path / f"{output_prefix}_FINAL.csv"
    save_csv_with_header(str(output_csv), H_result, pixel_size_mm)
    
    logger.info("\n" + "="*70)
    logger.info("GENERATING PLOTS")
    logger.info("="*70)
    
    plot_heightmap_with_overlaps(H_result, all_results, pixel_size_mm, first_file_width_px, str(output_path / output_prefix))
    plot_heightmap_clean(H_result, pixel_size_mm, str(output_path / output_prefix))
    plot_profiles_with_overlaps(H_result, all_results, pixel_size_mm, first_file_width_px, str(output_path / output_prefix))
    
    # ✅ GENERAR REPORTE DE CALIDAD
    if verify_quality:
        generate_quality_report(all_results, output_path / f"{output_prefix}_quality_report.txt")
    
    # ✅ CALCULAR LONGITUD PIEZA
    valid_cols = []
    for col in range(H_result.shape[1]):
        if np.sum(~np.isnan(H_result[:, col])) > H_result.shape[0] * 0.1:
            valid_cols.append(col)
    
    if valid_cols:
        piece_length_px = valid_cols[-1] - valid_cols[0] + 1
        piece_length_mm = piece_length_px * pixel_size_mm
    else:
        piece_length_mm = H_result.shape[1] * pixel_size_mm
    
    logger.info("="*70)
    logger.info("SUMMARY")
    logger.info("="*70)
    logger.info(f"Files stitched: {len(csv_files)}")
    logger.info(f"XY Calibration: {pixel_size_mm*1000:.3f} um")
    logger.info(f"Final shape: {H_result.shape} pixels")
    logger.info(f"Piece length: {piece_length_mm:.2f} mm")
    logger.info(f"Piece height: {H_result.shape[0]*pixel_size_mm:.2f} mm")
    
    for i, res in enumerate(all_results):
        quality_str = ""
        if res.overlap_metrics:
            quality_str = f" | Quality: {res.overlap_metrics.verdict} (MAE={res.overlap_metrics.mae_um:.2f}µm)"
        logger.info(f"  Overlap {i+1}: {res.overlap_mm:.2f} mm{quality_str}")
    
    return H_result, all_results, pixel_size_mm


if __name__ == "__main__":
    config = StitchConfig(
        pixel_size_mm=0.007413, expected_overlap_mm=3.0, max_delta_z_mm=0.15,
        min_snr=3.0, max_row_shift_px=15, smoothing_sigma=1.0, use_fallback=True
    )
    
    csv_files = [
        r"C:\Users\javie\Desktop\Universidad\Cuarto-Univesrity of Rhode Island\Primer Cuatrimestre\ISE 401 TFG\ProyectoLaser\Stitching\1.1Height.csv",
        r"C:\Users\javie\Desktop\Universidad\Cuarto-Univesrity of Rhode Island\Primer Cuatrimestre\ISE 401 TFG\ProyectoLaser\Stitching\1.2Height.csv",
        r"C:\Users\javie\Desktop\Universidad\Cuarto-Univesrity of Rhode Island\Primer Cuatrimestre\ISE 401 TFG\ProyectoLaser\Stitching\1.3Height.csv",
        r"C:\Users\javie\Desktop\Universidad\Cuarto-Univesrity of Rhode Island\Primer Cuatrimestre\ISE 401 TFG\ProyectoLaser\Stitching\1.4Height.csv"
    ]
    
    H_final, results, pixel_size = stitch_multiple_files(
        csv_files, output_dir=".", output_prefix=f"heightmap_{datetime.now().strftime('%Y%m%d_%H%M')}",
        config=config, interactive=True, verify_quality=True  # ✅ ACTIVAR VERIFICACIÓN
    )
    
    logger.info("✅ COMPLETED")